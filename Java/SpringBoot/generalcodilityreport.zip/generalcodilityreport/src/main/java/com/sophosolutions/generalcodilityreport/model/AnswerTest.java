package com.sophosolutions.generalcodilityreport.model;

import java.util.List;

public class AnswerTest {	
	private List<Test> results;

	public List<Test> getResults() {
		return results;
	}

	public void setResults(List<Test> results) {
		this.results = results;
	}
	
}
