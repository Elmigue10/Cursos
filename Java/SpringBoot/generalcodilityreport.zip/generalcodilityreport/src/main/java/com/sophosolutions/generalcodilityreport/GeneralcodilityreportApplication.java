package com.sophosolutions.generalcodilityreport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GeneralcodilityreportApplication {

	public static void main(String[] args) {
		SpringApplication.run(GeneralcodilityreportApplication.class, args);
	}

}
