package com.sophosolutions.generalcodilityreport.model;

import java.util.List;

public class AnswerCandidate {
	private List<Candidate> results;

	public List<Candidate> getResults() {
		return results;
	}

	public void setResults(List<Candidate> results) {
		this.results = results;
	}
	
}
