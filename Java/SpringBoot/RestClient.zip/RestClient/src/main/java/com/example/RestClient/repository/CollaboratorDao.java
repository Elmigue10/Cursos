package com.example.RestClient.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import com.example.RestClient.models.CollaboratorRp;

@Repository
public class CollaboratorDao {
	
	public static final String HASH_KEY = "Collaborator";
    @Autowired
    private RedisTemplate template;
    
    public CollaboratorRp save(CollaboratorRp collaborator) {
    	template.opsForHash().put(HASH_KEY,collaborator.getEmail(),collaborator);
        return collaborator;
    }
    
    public List<CollaboratorRp> findAll(){
        return template.opsForHash().values(HASH_KEY);
    }
    
    public CollaboratorRp findById(String id) {
    	return ( CollaboratorRp )template.opsForHash().get(HASH_KEY, id);
    }
}
