package com.example.RestClient.serviceImpl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.example.RestClient.config.Config;
import com.example.RestClient.models.Answer;
import com.example.RestClient.models.CollaboratorRp;
import com.example.RestClient.models.CollaboratorRp2;
import com.example.RestClient.repository.CollaboratorDao;
import com.example.RestClient.service.ICollaboratorService;

@Component
public class CollaboratorServiceImpl implements ICollaboratorService {

	@Autowired
	private CollaboratorDao collaboratorDao;

	@Autowired
	private Config config;
	
	private RestTemplate rest = new RestTemplate();
	
	private static final String CARPETA_ARCHIVO = System.getProperty("user.home")
												+ File.separator + "ReportesCodility";
	
	private static final String RUTA_ARCHIVO = CARPETA_ARCHIVO + File.separator;

	@Override
	public List<CollaboratorRp> findAll() {
		String url = config.getUri();
		org.springframework.http.HttpHeaders headers = 
				new org.springframework.http.HttpHeaders();
		headers.set("Authorization", config.getToken());
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		ResponseEntity<Answer> response = rest.exchange(url,
				HttpMethod.GET, entity, Answer.class);
		String datos = response.getBody().getNext();
		List<CollaboratorRp> resultados = response.getBody().getresults();
		while (datos != null) {
			ResponseEntity<Answer> response2 = rest.exchange(datos, 
					HttpMethod.GET, entity, Answer.class);
			datos = response2.getBody().getNext();
			for (CollaboratorRp colaborador : response2.getBody().getresults())
				resultados.add(colaborador);
		}
		for (CollaboratorRp col : resultados) {
			CollaboratorRp collaborator = new CollaboratorRp();
			collaborator.setEmail(col.getId());
			collaborator.setId(col.getEmail());
			System.out.println(collaborator.toString());
			collaboratorDao.save(collaborator);
		}
		System.out.println("Tamaño " + resultados.size());

		// SE DEBE GUARDAR LOS DATOS
		return resultados;
	}

	@Override
	public CollaboratorRp2 findByEmail(String email) {

		CollaboratorRp collaborator = collaboratorDao.findById(email);

		final String uri = config.getUri();
		String url = config.getUri() + collaborator.getEmail();
		org.springframework.http.HttpHeaders headers = 
				new org.springframework.http.HttpHeaders();
		headers.set("Authorization", config.getToken());
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		ResponseEntity<CollaboratorRp2> response = rest.exchange(url,
				HttpMethod.GET, entity, CollaboratorRp2.class);
		
		downloadPdf(collaborator.getEmail());
		
		return response.getBody();
	}

	@Override
	public String downloadPdf(String id) {

		File carpeta = new File (CARPETA_ARCHIVO);
		if(!carpeta.exists()) {
			carpeta.mkdirs();
		}
		
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", config.getToken());
		headers.setContentType(MediaType.parseMediaType("application/pdf"));
		HttpEntity<String> entity = new HttpEntity<>(headers);
		String path = config.getUri() + id + "/pdf";
		System.out.println(path);
		ResponseEntity<byte[]> responseEntity = rest.exchange(path,
				HttpMethod.GET, entity, byte[].class);
		System.out.println(responseEntity);
		byte[] content = responseEntity.getBody();
		try {
			Files.write(Paths.get(RUTA_ARCHIVO + id + ".pdf"), content,
					StandardOpenOption.CREATE);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return "archivo descargado.";
	}

}
