package com.example.RestClient.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.RestClient.models.CollaboratorRp;

@Repository
public interface CollaboratorRepository extends CrudRepository<CollaboratorRp, String>{

	
	
}
