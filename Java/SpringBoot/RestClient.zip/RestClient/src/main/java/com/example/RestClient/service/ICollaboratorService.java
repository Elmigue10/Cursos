package com.example.RestClient.service;

import java.util.List;

import com.example.RestClient.models.CollaboratorRp;
import com.example.RestClient.models.CollaboratorRp2;

public interface ICollaboratorService {

	public abstract List<CollaboratorRp> findAll();
	
	public abstract CollaboratorRp2 findByEmail(String email);
	
	public abstract String downloadPdf(String id);
	
}
