package com.example.RestClient.controllers;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.RestClient.models.CollaboratorRp;
import com.example.RestClient.models.CollaboratorRp2;
import com.example.RestClient.models.CollaboratorRq;
import com.example.RestClient.repository.CollaboratorDao;
import com.example.RestClient.repository.CollaboratorRepository;
import com.example.RestClient.serviceImpl.CollaboratorServiceImpl;


@RestController
@RequestMapping("/collaborator")
public class ConsumoController {
	
	@Autowired
	public CollaboratorRepository collaboratorRepository;
	
	@Autowired
	public CollaboratorDao collaboratorDao;
	
	@Autowired
	private CollaboratorServiceImpl servicio;
	
	
	@PostConstruct	
	public List<CollaboratorRp> findAll()
	{
		return servicio.findAll();
	}
	
	@GetMapping("/list")
	public List<CollaboratorRp> findCollaborators(){
		return collaboratorDao.findAll();
	}
	
	@PostMapping("/find")
	public CollaboratorRp2 find(@RequestBody CollaboratorRq data) {
		return servicio.findByEmail(data.getEmail());
	}
}
