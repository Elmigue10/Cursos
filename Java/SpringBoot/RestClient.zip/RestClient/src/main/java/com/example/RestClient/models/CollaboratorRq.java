package com.example.RestClient.models;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CollaboratorRq implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@JsonProperty(required = true)
	private String email;
	
	public CollaboratorRq()
	{
		
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}	
	
}
