package Capa_negocio;
import java.util.ArrayList;
import java.sql.*;
import Capa_datos.Conexion;

public class Dato_articulo 
{
    private String cedula;
    private String nombre;
    private String celular;
    private String placa;
    private String tipo_vehiculo;
    private String kilometraje;
    
    public String EliminarArticulo ()
    {
        Conexion objmod=new Conexion();
        String cad="delete from cliente where cedula='"+this.getcedula()+"'";
        return objmod.Ejecutar(cad);
    }
    public String GrabarArticulo()
    {
        Conexion objmod=new Conexion();
        String cad="insert into cliente values('"+this.getcedula()
                +"','"+this.getnombre()+"','"+this.getcelular()+"','"
                +this.getplaca()+"','"+this.gettipo_vehiculo()+"','"
                +this.getkilometraje()+"')";
        return objmod.Ejecutar(cad);
    }
    public String EditarArticulo()
    {
        Conexion objmod=new Conexion();
        String cad="update cliente set nombre='"+this.getnombre()
                +"',celular='"+this.getcelular()+"',placa='"+this.getplaca()
                +"',tipo_vehiculo='"+this.gettipo_vehiculo()+"',kilometraje='"+this.getkilometraje()
                +"' where cedula='"+this.getcedula()+"'";
        return objmod.Ejecutar(cad);
    }
    public ArrayList<Dato_articulo> ListaArticulos()
    {
        ArrayList lista2=new ArrayList();
        try
        {
            Conexion objmod=new Conexion ();
            ResultSet tabla=objmod.Listar("select * from cliente");
            Dato_articulo objart;
            while(tabla.next())
            {
                objart=new Dato_articulo();
                objart.setcedula(tabla.getString("cedula"));
                objart.setnombre(tabla.getString("nombre"));
                objart.setcelular(tabla.getString("celular"));
                objart.setplaca(tabla.getString("placa"));
                objart.settipo_vehiculo(tabla.getString("tipo_vehiculo"));
                objart.setkilometraje(tabla.getString("kilometraje"));
                lista2.add(objart);
                
            }
        }
        catch(Exception e)
        {
            javax.swing.JOptionPane.showMessageDialog(null,e.getMessage());
        }
        return lista2;
    }
    public String getcedula(){
        return cedula;
    }
    public void setcedula(String cedula){
        this.cedula=cedula;
    }
    public String getnombre(){
        return nombre;
    }
    public void setnombre(String nombre){
        this.nombre=nombre;
    }
    public String getcelular(){
        return celular;
    }
    public void setcelular(String celular){
        this.celular=celular;
    }
    public String getplaca(){
        return placa;
    }
    public void setplaca(String placa){
        this.placa=placa;
    }
    public String gettipo_vehiculo(){
        return tipo_vehiculo;
    }
    public void settipo_vehiculo(String tipo_vehiculo){
        this.tipo_vehiculo=tipo_vehiculo;
    }
    public String getkilometraje(){
        return kilometraje;
    }
    public void setkilometraje(String kilometraje){
        this.kilometraje=kilometraje;
    }
}
